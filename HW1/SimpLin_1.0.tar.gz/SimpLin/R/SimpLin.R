
SimpLinR <- function(x,y) {
  SimpLinCpp(x, y)
}