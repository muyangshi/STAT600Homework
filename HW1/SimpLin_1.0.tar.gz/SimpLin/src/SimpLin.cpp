#include "RcppArmadillo.h"
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::export]]
Rcpp::List SimpLinCpp(arma::vec x, arma::vec y){
  
  int n       = x.n_elem;
  arma::mat X = arma::join_horiz(arma::ones(n), x); // design matrix
  int k       = X.n_cols;
  
  // Coefficient
  arma::vec coef   = arma::inv(arma::trans(X) * X) * arma::trans(X) * y;
  
  // Standard Errors
  arma::vec resids = y - X * coef;
  double sigma2 = arma::accu(arma::square(resids))/(n-k);
  double sigma  = std::sqrt(sigma2);
  arma::vec StdErr = sigma * arma::diagmat(arma::inv(arma::trans(X) * X));
  
  
  Rcpp::List results;
  results["Coefficients"] = coef;
  results["Std. Errors"] = StdErr;
  // results["95% LB"] = 0;
  // results["95% UB"] = 0;
  // results["Residuals"] = 0;
  // results["Predicted Values"] = 0;
  return results;
}
